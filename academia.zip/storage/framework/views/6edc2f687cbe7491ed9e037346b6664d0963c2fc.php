<?php $__env->startSection('contenido'); ?>

<div class="container-fluid">


	<div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Matricula</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('enrollments.create')); ?>">Agregar Matricula</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
     </div>


     <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Registro de Matricula</h5>
                                <div class="f-right">
                                	<a href="<?php echo e(route('enrollments.create')); ?>" class="btn btn-info">Agregar Nueva Matricula</a>
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>


                                </div>


                            </div>

<div class="card-block">

<div class="container">

       	 <?php echo Form::open(['route' => 'enrollments.index', 'method' => 'GET', 'class' => 'form-inline my-2 my-lg-0', 'role' => 'search']); ?>



       	 <?php echo Form::text('search', null , ['class' => 'form-control mr-sm-2']); ?>




      		<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
    	 <?php echo Form::close(); ?>

    </div>
	<table class="table table-hover">
	

<thead>
	<tr>
	<th>ID</th>
	<th>Nombre</th>
	<th>Codigo</th>
	<th>Monto</th>
	<th>Estado</th>
	<th>Nivel</th>
	<th>Acciones</th>
	</tr>
</thead>
<tbody>
	
	<?php $__currentLoopData = $enrollment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($enrollments->id); ?></td>

	<td>
		<?php echo e($enrollments->student->nombres); ?></td>

	<td>

		<a href="<?php echo e(route('enrollments.show', $enrollments->id)); ?>"><?php echo e($enrollments->user->username); ?></a>

	</td>

	<td><?php echo e($enrollments->monto); ?></td>

	<td><?php echo e($enrollments->estado); ?></td>

	<td><?php echo e($enrollments->programming->nivel); ?></td>

	<td>
				<a class="btn btn-info btn-xs" href="<?php echo e(route('enrollments.edit', $enrollments->id)); ?>">Editar</a>


				<form  class="deleteenrollment" style="display: inline;" method="POST" action=" <?php echo e(route('enrollments.destroy', $enrollments->id)); ?>">

					<?php echo csrf_field(); ?>

					<?php echo method_field('DELETE'); ?>

					
					<button class="btn btn-danger btn-xs " type="submit">Eliminar</button>

				</form>
	</td>

</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php echo e($enrollment->links('vendor.pagination.bootstrap-4')); ?>


</div>

</div>
</div>
</div>




                
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>