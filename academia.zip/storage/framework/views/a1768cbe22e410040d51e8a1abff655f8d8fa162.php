<?php $__env->startSection('contenido'); ?>

<div class="container-fluid">

    <?php if(session()->has('info')): ?>


    <div class="alert alert-success"><?php echo e(session('info')); ?></div>

    <?php else: ?>
            <!-- Main content starts -->
            <div>
                <!-- Row Starts -->
                <div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Programacion</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('programmings.create')); ?>">Agregar Programacion</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
                </div>
                    <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Registro de Programacion</h5>
                                <div class="f-right">
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>
                                </div>
                            </div>

<div class="card-block">
<form method="POST" action=" <?php echo e(route('programmings.store')); ?> ">

    <?php echo csrf_field(); ?>


<div class="form-group">

       <label for="fecha" class="form-control-label">Fecha</label>
    
        <input class="form-control" type="date" value="<?php echo e(old('fecha')); ?>" id="fecha" name="fecha">

        <?php echo $errors->first('fecha','<span class=error>:message</span>'); ?>

</div>

<div class="form-group">
    <label for="nivel" class="form-control-label">nivel</label>
    <input type="text" class="form-control" id="nivel" aria-describedby="emailHelp" placeholder="nivel" name="nivel" value="<?php echo e(old('nivel')); ?>">

    <?php echo $errors->first('nivel','<span class=error>:message</span>'); ?>

</div>
 
 
<div class="form-group">
    <label for="grado" class="form-control-label">grado</label>
        <input type="text" class="form-control" id="grado" placeholder="grado"  name="grado" value="<?php echo e(old('grado')); ?>">

        <?php echo $errors->first('grado','<span class=error>:message</span>'); ?>

</div>

<div class="form-group">
    <label for="turno" class="form-control-label">turno</label>
        <input type="text" class="form-control" id="turno" placeholder="turno"  name="turno" value="<?php echo e(old('turno')); ?>">

        <?php echo $errors->first('turno','<span class=error>:message</span>'); ?>

</div>

<div class="form-group">
    <label for="estado" class="form-control-label">estado</label>
        <input type="text" class="form-control" id="estado" placeholder="estado"  name="estado" value="<?php echo e(old('estado')); ?>">

        <?php echo $errors->first('estado','<span class=error>:message</span>'); ?>

</div>


<div class="form-group">
    <label for="classroom_id" class="form-control-label">Salon</label>
        
        <select name="classroom_id">

            <?php $__currentLoopData = $classroom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classrooms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <option value="<?php echo e($classrooms->id); ?>"> <?php echo e($classrooms->nombre); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <?php echo $errors->first('classroom_id','<span class=error>:message</span>'); ?>

</div>





<input class="btn btn-success waves-effect waves-light m-r-30" type="submit" name="Enviar">

</form>
</div>
</div>
</div>
    </div>
    </div>
    </div>



<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>