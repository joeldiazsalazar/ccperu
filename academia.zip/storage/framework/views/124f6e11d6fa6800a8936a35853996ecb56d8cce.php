<?php $__env->startSection('contenido'); ?>

  <div>
                <!-- Row Starts -->
                <div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Notas</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>

                            </ol>
                        </div>
                    </div>
                </div>
                    <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Registro de Notas</h5>
                                <div class="f-right">
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>
                                </div>
                            </div>

<div class="card-block">


<form method="POST" action=" <?php echo e(route('teachers.sendQualification')); ?> " onsubmit="return checkSubmit();">
	<?php echo csrf_field(); ?>

	<table class="table">
		<h4>Descripcion</h4>

		<?php $__currentLoopData = $trimester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ttr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<input type="checkbox" name="trimester_id" value="<?php echo e($ttr->id); ?>" checked=""><?php echo e($ttr->name); ?>

	
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


		<thead>
			<tr>
				<td>PROGRAMACION</td>
				<td>CURSO</td>
				<td>Docente</td>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $ddNote; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><input type="checkbox" checked name="programming_id" value="<?php echo e($desk->programming_id); ?>"> <?php echo e($desk->programming->nivel .'  '. $desk->programming->classroom->nombre .''. $desk->programming->classroom->pabellon); ?></td>
				<td>
					<input type="checkbox" checked name="course_id" value="<?php echo e($desk->course_id); ?>"><?php echo e($desk->course->name); ?>

					
				</td>

				<td><input type="checkbox" checked value="<?php echo e($desk->teacher_id); ?>" name="teacher_id"> <?php echo e($desk->teacher->nombres); ?></td>
			
			</tr>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



		</tbody>
	</table>
<table class="table-responsive table-hover">
	<thead>
		<tr>
			<td>PROGRAMACION DE CURSO</td>

			<tr>
			<td>ALUMNO</td>
			<td class="">Nota 1</td>
            <td class="">Notas 2</td>
            <td class="">Notas 3</td>
            <td class="">Notas 4</td>
            <td class="">Promedio</td> 

			</tr>
		</tr>
	</thead>


	<tbody>

    
	    	
		<?php $__currentLoopData = $ddNote; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			
		<tr>

			<?php $__currentLoopData = $pro->programming->enrollment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wtf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr class="row">
			<td> 
				<input type="checkbox" name="user_id[]" checked value="<?php echo e($wtf->user_id); ?>"><?php echo e($wtf->user->name); ?>

			</td>
			 <td><input type="text" name="nota1[<?php echo e($not1++); ?>]"  id="note1_<?php echo e($id1++); ?>"  style="width: 70px; text-align: center;" onkeyup="calcular(<?php echo e($met1++); ?>);" maxlength="2" ></td>
             <td> <input type="text" name="nota2[<?php echo e($not2++); ?>]"  id="note2_<?php echo e($id2++); ?>"  style="width: 70px; text-align: center;" onkeyup="calcular(<?php echo e($met2++); ?>)" maxlength="2"></td>
             <td> <input type="text" name="nota3[<?php echo e($not3++); ?>]"  id="note3_<?php echo e($id3++); ?>"  style="width: 70px; text-align: center;"  onkeyup="calcular(<?php echo e($met3++); ?>)" maxlength="2"></td>
             <td> <input type="text" name="nota4[<?php echo e($not4++); ?>]"  id="note4_<?php echo e($id4++); ?>"  style="width: 70px; text-align: center;" onkeyup="calcular(<?php echo e($met4++); ?>)" maxlength="2"></td>
             <td> <input type="text" name="promedio[<?php echo e($prom++); ?>]"  id="prom_<?php echo e($id5++); ?>"  style="width: 70px; text-align: center;" ></td>
         
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</tr>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>

<input class="btn btn-success waves-effect waves-light m-r-30" type="submit" name="Enviar" id="btn_note">

</form>

</div>
</div>
</div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>