<?php $__env->startSection('contenido'); ?>


<?php if( session()->has('info')): ?>
<div class="alert alert-success"><?php echo e(session('info')); ?></div>

<?php endif; ?>
<div class="container-fluid">


  <div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Usuarios</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>                              
                            </ol>
                        </div>
                    </div>
     </div>


     <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">

                              <?php if(auth()->check()): ?>

                              <?php if(auth()->user()->hasRoles(['admin'])): ?>
                              <h5 class="card-header-text">Asignacion de Usuarios</h5>

                              <?php elseif(auth()->user()->hasRoles(['alumno'])): ?>
                              <h5 class="card-header-text">Cambiar contraseña</h5>

                              <?php elseif(auth()->user()->hasRoles(['docente'])): ?>
                              <h5 class="card-header-text">Cambiar contraseña</h5>

                              <?php elseif(auth()->user()->hasRoles(['apoderado'])): ?>
                              <h5 class="card-header-text">Cambiar contraseña</h5>

                              <?php endif; ?>

                              <?php endif; ?>


                         </div>

<div class="card-block">


<form method="POST" action=" <?php echo e(route('users.update', $user->id)); ?> " enctype="multipart/form-data">
	<?php echo method_field('PUT'); ?>


	<?php echo csrf_field(); ?>


<?php if(auth()->check()): ?>

<?php if(auth()->user()->hasRoles(['admin'])): ?>

  <div class="form-group col-md-4">
    
    <img src="<?php echo e(Storage::url($user->avatar)); ?>" style="width: 150px; height: 150px;">
 
  </div>

  <div class="form-group col-md-4">
    
    <p><label for="nombre">
               Nombre

        <input class="form-control" type="text" name="name" value="<?php echo e($user->name); ?>">

  <?php echo $errors->first('name','<span class=error>:message</span>'); ?>

  </label></p>

  </div>
	<div class="form-group col-md-4">

<p><label for="username">
	Username
	<input class="form-control" type="text" name="username" value="<?php echo e($user->username); ?>">

	<?php echo $errors->first('username','<span class=error>:message</span>'); ?>

</label>
</p>
</div>
<?php if (! ($user->id)): ?>
<div class="form-group col-md-6">
    <label for="password" class="form-control-label">Password</label>
        <input type="password" class="form-control" id="password" placeholder="Password" name="password">

        <?php echo $errors->first('password','<span class=error>:message</span>'); ?>

</div>
<div class="form-group col-md-6">
    <label for="password_confirmation" class="form-control-label">Password</label>
        <input type="password" class="form-control" id="password_confirmation" placeholder="password_confirmation" name="password_confirmation" >

        <?php echo $errors->first('password_confirmation','<span class=error>:message</span>'); ?>

</div>
<?php endif; ?>

<?php endif; ?>
<?php endif; ?>

<?php if(auth()->check()): ?>

<?php if(auth()->user()->hasRoles(['alumno'])): ?>
<div class="form-group col-md-6">
    <label for="password" class="form-control-label">Password</label>
        <input type="password" class="form-control" id="password" placeholder="Password" name="password">

        <?php echo $errors->first('password','<span class=error>:message</span>'); ?>

</div>
<div class="form-group col-md-6">
    <label for="password_confirmation" class="form-control-label">Password</label>
        <input type="password" class="form-control" id="password_confirmation" placeholder="password_confirmation" name="password_confirmation" >

        <?php echo $errors->first('password_confirmation','<span class=error>:message</span>'); ?>

</div>
<?php elseif(auth()->user()->hasRoles(['docente'])): ?>
<div class="form-group col-md-6">
    <label for="password" class="form-control-label">Password</label>
        <input type="password" class="form-control" id="password" placeholder="Password" name="password">

        <?php echo $errors->first('password','<span class=error>:message</span>'); ?>

</div>
<div class="form-group col-md-6">
    <label for="password_confirmation" class="form-control-label">Password</label>
        <input type="password" class="form-control" id="password_confirmation" placeholder="password_confirmation" name="password_confirmation" >

        <?php echo $errors->first('password_confirmation','<span class=error>:message</span>'); ?>

</div>

<?php elseif(auth()->user()->hasRoles(['apoderado'])): ?>
<div class="form-group col-md-6">
    <label for="password" class="form-control-label">Password</label>
        <input type="password" class="form-control" id="password" placeholder="Password" name="password">

        <?php echo $errors->first('password','<span class=error>:message</span>'); ?>

</div>
<div class="form-group col-md-6">
    <label for="password_confirmation" class="form-control-label">Password</label>
        <input type="password" class="form-control" id="password_confirmation" placeholder="password_confirmation" name="password_confirmation" >

        <?php echo $errors->first('password_confirmation','<span class=error>:message</span>'); ?>

</div>

<?php endif; ?>
<?php endif; ?>

<?php if(auth()->check()): ?>

<?php if(auth()->user()->hasRoles(['admin'])): ?>

<div class="container">
<div class="row">
  

<ul class="nav nav-tabs col-md-12  tabs" role="tablist">
    <li class="nav-item">
        <a class="nav-link active" data-toggle="tab" href="#home1" role="tab">Asignacion Alumnos<a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#profile1" role="tab">Asignacion Apoderado</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#messages1" role="tab">Asignacion Docentes</a>
    </li>
 
</ul>

<div class="tab-content tabs">
    <div class="tab-pane active" id="home1" role="tabpanel">
       

 <div class="form-group">
    <label for="student" class="form-control-label"></label>
        <select class="form-control" id="edit-asig" name="student">
           
          <option value="">Seleccione Alumno</option>
           <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id =>$email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($id); ?>"
            <?php echo e($user->student->pluck('id')->contains($id) ? 'selected="selected"' : ''); ?>>
            <?php echo e($email); ?>

            </option>
         
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <?php echo $errors->first('student','<span class=error>:message</span>'); ?>

</div>     

    </div>
    <div class="tab-pane" id="profile1" role="tabpanel">
       <div class="form-group">
    <label for="attorney" class="form-control-label"></label>
        <select class="form-control" id="edit-asig" name="attorney">
           
          <option value="">Seleccione Apoderado</option>
           <?php $__currentLoopData = $attorneys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id =>$dni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($id); ?>"
            <?php echo e($user->attorney->pluck('id')->contains($id) ? 'selected="selected"' : ''); ?>>
            <?php echo e($dni); ?>

            </option>
         
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <?php echo $errors->first('attorney','<span class=error>:message</span>'); ?>

</div>
    </div>
    <div class="tab-pane" id="messages1" role="tabpanel">
       
             <div class="form-group">
    <label for="teacher" class="form-control-label"></label>
        <select class="form-control" id="edit-asig" name="teacher">
           
          <option value="">Seleccione Apoderado</option>
           <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id =>$correo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($id); ?>"
            <?php echo e($user->teacher->pluck('id')->contains($id) ? 'selected="selected"' : ''); ?>>
            <?php echo e($correo); ?>

            </option>
         
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <?php echo $errors->first('teacher','<span class=error>:message</span>'); ?>

</div>

    </div>
  
</div>
</div>
</div>

<?php endif; ?>
<?php endif; ?>

<input class="btn btn-primary" type="submit" name="Enviar">

</form>

</div>

</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>