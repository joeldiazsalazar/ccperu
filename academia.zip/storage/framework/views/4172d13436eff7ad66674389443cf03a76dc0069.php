<?php $__env->startSection('contenido'); ?>

<div class="container-fluid">


	<div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Calificaciones</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('qualifications.create')); ?>">Agregar Calificacion</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
     </div>


     <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Registro de Calificaciones</h5>
                                <div class="f-right">
                                	<a href="<?php echo e(route('qualifications.create')); ?>" class="btn btn-info">Agregar Nueva Calificacion</a>
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>


                                </div>


                            </div>

<div class="card-block">
<div class="container">

       	 <?php echo Form::open(['route' => 'qualifications.index', 'method' => 'GET', 'class' => 'form-inline my-2 my-lg-0', 'role' => 'search']); ?>



       	 <?php echo Form::text('search', null , ['class' => 'form-control mr-sm-2']); ?>




      		<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
    	 <?php echo Form::close(); ?>

    </div>

	<table class="table table-hover">
	

<thead>
	<tr>
	<th>Alumno</th>
	<th>Codigo</th>
	<th>Trimestre</th>
	<th>Curso</th>
	<th>nota1</th>
	<th>nota2</th>
	<th>nota3</th>
	<th>nota4</th>
	<th>promedio</th>

	<th>Acciones</th>
	</tr>
</thead>
<tbody>
	
	<?php $__currentLoopData = $qualification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qualifications): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($qualifications->user->name); ?></td>
	<td><?php echo e($qualifications->user->username); ?></td>

	<td><?php echo e($qualifications->trimester->name); ?></td>

	<td><?php echo e($qualifications->course->name); ?></td>

	<td><?php echo e($qualifications->nota1); ?></td>

	<td><?php echo e($qualifications->nota2); ?></td>
		
	<td><?php echo e($qualifications->nota3); ?></td>
			
	<td><?php echo e($qualifications->nota4); ?></td>
				
	<td><?php echo e($qualifications->promedio); ?></td>

	<td>
				<a class="btn btn-info btn-xs" href="<?php echo e(route('qualifications.edit', $qualifications->id)); ?>">Editar</a>


			
	</td>

</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php echo e($qualification->links('vendor.pagination.bootstrap-4')); ?>


</div>

</div>
</div>
</div>




                
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>