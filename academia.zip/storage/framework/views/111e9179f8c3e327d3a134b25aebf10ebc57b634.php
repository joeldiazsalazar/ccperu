<?php $__env->startSection('contenido'); ?>

<div class="container-fluid">

    <?php if(session()->has('info')): ?>


    <div class="alert alert-success"><?php echo e(session('info')); ?></div>

    <?php else: ?>
            <!-- Main content starts -->
            <div>
                <!-- Row Starts -->
                <div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Matricula</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('enrollments.create')); ?>">Agregar Matricula</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
                </div>
                    <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Registro de Matriculas</h5>
                                <div class="f-right">
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>
                                </div>
                            </div>

<div class="card-block">
<form method="POST" action=" <?php echo e(route('enrollments.store')); ?> ">

    <?php echo csrf_field(); ?>


<div class="form-group">
    <label for="student_id" class="form-control-label">Alumno</label>
    <select name="student_id">
    <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($students->id); ?>"> <?php echo e($students->nombres); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</select>

    <?php echo $errors->first('student_id','<span class=error>:message</span>'); ?>

</div>

<div class="form-group">
    <label for="user_id" class="form-control-label">User</label>
    <select name="user_id">
    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($users->id); ?>"> <?php echo e($users->username); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>

    <?php echo $errors->first('user_id','<span class=error>:message</span>'); ?>

</div>

<div class="form-group">
    <label for="monto" class="form-control-label">Monto</label>
        <input type="text" name="monto">

    <?php echo $errors->first('monto','<span class=error>:message</span>'); ?>

</div>

<div class="form-group">
    <label for="estado" class="form-control-label">estado</label>
    
<br>
        <label class="radio-inline"><input type="radio" name="estado" value="activo">Cancelado</label>
        <label class="radio-inline"><input type="radio" name="estado" value="inactivo">Pendiente</label>  

    <?php echo $errors->first('estado','<span class=error>:message</span>'); ?>

</div>


<div class="form-group">
    <label for="programming_id" class="form-control-label">Nivel</label>
    <select name="programming_id" id="mibuscador">
    <?php $__currentLoopData = $programming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programmings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($programmings->id); ?>"> <?php echo e($programmings->nivel . ' - ' .$programmings->grado . '- ' .$programmings->classroom->pabellon); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>

    <?php echo $errors->first('programming_id','<span class=error>:message</span>'); ?>

</div>


 
<input class="btn btn-success waves-effect waves-light m-r-30" type="submit" name="Enviar">

</form>
</div>
</div>
</div>
    </div>
    </div>
    </div>



<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>