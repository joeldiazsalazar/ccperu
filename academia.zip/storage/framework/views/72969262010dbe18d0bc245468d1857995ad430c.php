<?php $__env->startSection('contenido'); ?>

<section class="panels-wells">

      <div class="card">
       <div class="card-header"><h5 class="card-header-text">INSTITUCION EDUCATIVA CESAR vallejo mendoza</h5></div>
        <div class="card-block">
          <center><img src="<?php echo e(asset('/img/banner.jpg')); ?>" class="img-fluid" style="text-align: center;"></center>
      </div>
    </div>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>