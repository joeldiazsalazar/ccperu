<?php $__env->startSection('contenido'); ?>


<h1>MOSTRAR CURSOS</h1>


 <?php if(auth()->check()): ?>


<table class="table table-hover">
	

<thead>
	<tr>
	<th>ID</th>
	<th>Cursos</th>
	</tr>
</thead>
<tbody>
	<?php $__currentLoopData = $dett; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
	<td>      
		<a href="<?php echo e(route('course_note.show', $courses->id )); ?>"><?php echo e($courses->course->name); ?></a>

	</td>

	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>