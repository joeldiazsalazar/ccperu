<?php $__env->startSection('contenido'); ?>

<?php if( session()->has('info')): ?>
<div class="alert alert-success"><?php echo e(session('info')); ?></div>

<?php endif; ?>

<div class="container-fluid">


    <div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Apoderados</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="">Editar Apoderados</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
     </div>


                    <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Edicion de Apoderados</h5>
                                <div class="f-right">
                                
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>


                                </div>


                            </div>

<div class="card-block">



<form method="POST" action=" <?php echo e(route('attorneys.update', $attorney->id)); ?> ">
    <?php echo method_field('PUT'); ?>


    <?php echo csrf_field(); ?>


<div class="form-group col-md-4">
<label for="nombres" class="form-control-label">Nombre Completo</label>

    <input class="form-control" type="text" name="nombres" value="<?php echo e($attorney->nombres); ?>">

    <?php echo $errors->first('nombres','<span class=error>:message</span>'); ?>

</label>

</div>
<div class="form-group col-md-4">
<label for="apellidoPaterno" class="form-control-label"> Apellido Paterno </label>
    
    <input class="form-control" type="text" name="apellidoPaterno" value="<?php echo e($attorney->apellidoPaterno); ?>">

    <?php echo $errors->first('apellidoPaterno','<span class=error>:message</span>'); ?>

</div>
<div class="form-group col-md-4">

<label for="apellidoMaterno" class="form-control-label">
    Apellido Materno</label>
    <input class="form-control" type="text" name="apellidoMaterno" value="<?php echo e($attorney->apellidoMaterno); ?>">

    <?php echo $errors->first('apellidoMaterno','<span class=error>:message</span>'); ?>


</div>

<div class="form-group col-md-4">

<label for="dni" class="form-control-label">
    DNI</label>
    <input class="form-control" type="text" name="dni" value="<?php echo e($attorney->dni); ?>">

    <?php echo $errors->first('dni','<span class=error>:message</span>'); ?>


</div>

<div class="form-group col-md-4">

<label for="sexo" class="form-control-label">
    Sexo</label>
    <input class="form-control" type="text" name="sexo" value="<?php echo e($attorney->sexo); ?>">

    <?php echo $errors->first('sexo','<span class=error>:message</span>'); ?>


</div>

<div class="form-group col-md-4">

<label for="est_civil" class="form-control-label">
    Estado civil</label>
   

<select name="est_civil" class="form-control">
    
    <?php $__currentLoopData = $att; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <option value="<?php echo e($aa->est_civil); ?>"> <?php echo e($aa->est_civil); ?> </option>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

    <?php echo $errors->first('est_civil','<span class=error>:message</span>'); ?>


</div>


<div class="form-group col-md-6">

    <label for="direccion" class="form-control-label">
    Direccion</label>
    <input class="form-control" type="text" name="direccion" value="<?php echo e($attorney->direccion); ?>">

    <?php echo $errors->first('direccion','<span class=error>:message</span>'); ?>


</div>


<div class="form-group col-md-6">

<label for="celular" class="form-control-label">
    Celular</label>
    <input class="form-control" type="text" name="celular" value="<?php echo e($attorney->celular); ?>">

    <?php echo $errors->first('celular','<span class=error>:message</span>'); ?>


</div>

<div class="form-group col-md-6">

<label for="estado" class="form-control-label">
    Estado</label>
    <input class="form-control" type="text" name="estado" value="<?php echo e($attorney->estado); ?>">

    <?php echo $errors->first('estado','<span class=error>:message</span>'); ?>


</div>

<div class="form-group col-md-12">
    
    <input class="btn btn-primary" type="submit" name="Enviar">

</div>

</form>



</div>

</div>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>