<?php $__env->startSection('contenido'); ?>








<div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Mi Horario</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                            
                                
                            </ol>
                        </div>
                    </div>
     </div>

<div class="container-fluid">
	
	<div class="card">
		
		<div class="card-header">
			<div class="card-block">
				
				<div class="row">
					

<div class="col-md-3 ">
						

<table class="table table-hover ">
<thead>
	<tr>
	<th>Lunes</th>
	</tr>
</thead>
<tbody>
	<?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
	<td>

		<?php echo e($detail->course->name); ?><br>
		<?php echo e($detail->teacher->nombres); ?><br>
		<?php echo e($detail->hour_start); ?> 
		<?php echo e($detail->hour_end); ?>	<br>	
		<?php echo e($detail->programming->classroom->nombre .'-'.$detail->programming->classroom->pabellon); ?>

	</td>
	</tr>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>	
<div class="col-md-2 ">
<table class="table table-hover">
	
	<thead>
		<tr>
			<th>
				Martes
			</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $det_mart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dd_m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
	<td>
		<?php echo e($dd_m->course->name); ?><br>
		<?php echo e($dd_m->teacher->nombres); ?><br>
		<?php echo e($dd_m->hour_start); ?> 
		<?php echo e($dd_m->hour_end); ?>	<br>	
		<?php echo e($dd_m->programming->classroom->nombre .'-'.$dd_m->programming->classroom->pabellon); ?>


	</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>


</table>

</div>

<div class="col-md-2 ">
<table class="table table-hover">
	
	<thead>
		<tr>
			<th>
				Miercoles
			</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $det_mier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dd_mier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
	<td>
		<?php echo e($dd_mier->course->name); ?><br>
		<?php echo e($dd_mier->teacher->nombres); ?><br>
		<?php echo e($dd_mier->hour_start); ?> 
		<?php echo e($dd_mier->hour_end); ?>	<br>	
		<?php echo e($dd_mier->programming->classroom->nombre .'-'.$dd_mier->programming->classroom->pabellon); ?>


	</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>


</table>

</div>

<div class="col-md-2 ">
<table class="table table-hover">
	
	<thead>
		<tr>
			<th>
				Jueves
			</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $det_juev; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dd_juev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
	<td>
		<?php echo e($dd_juev->course->name); ?><br>
		<?php echo e($dd_juev->teacher->nombres); ?><br>
		<?php echo e($dd_juev->hour_start); ?> 
		<?php echo e($dd_juev->hour_end); ?>	<br>	
		<?php echo e($dd_juev->programming->classroom->nombre .'-'.$dd_juev->programming->classroom->pabellon); ?>


	</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>


</table>

</div>

<div class="col-md-3 ">
<table class="table table-hover">
	
	<thead>
		<tr>
			<th>
				Viernes
			</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $det_vier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dd_vier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
	<td>
		<?php echo e($dd_vier->course->name); ?><br>
		<?php echo e($dd_vier->teacher->nombres); ?><br>
		<?php echo e($dd_vier->hour_start); ?> 
		<?php echo e($dd_vier->hour_end); ?>	<br>	
		<?php echo e($dd_vier->programming->classroom->nombre .'-'.$dd_vier->programming->classroom->pabellon); ?>


	</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>


</table>

</div>



					
				</div>
			</div>
		</div>
	</div>










</div>








<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>