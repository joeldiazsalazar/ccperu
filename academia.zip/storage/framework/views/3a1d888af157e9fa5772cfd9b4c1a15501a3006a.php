<?php $__env->startSection('contenido'); ?>

<div class="container-fluid">


	<div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Apoderados</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('attorneys.create')); ?>">Agregar Apoderado</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
     </div>


     <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Registro de Usuarios</h5>
                                <div class="f-right">

                                	<a href="<?php echo e(route('attorneys.create')); ?>" class="btn btn-info">Agregar Nuevo Apoderado</a>
                                	
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>


                                </div>


                            </div>

<div class="card-block">

<div class="container">

       	 <?php echo Form::open(['route' => 'attorneys.index', 'method' => 'GET', 'class' => 'form-inline my-2 my-lg-0', 'role' => 'search']); ?>



       	 <?php echo Form::text('search', null , ['class' => 'form-control mr-sm-2']); ?>




      		<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
    	 <?php echo Form::close(); ?>

    </div>

<table class="table table-hover">
	

<thead>
	<tr>
	<th>ID</th>
	<th>Nombres</th>
	<th>Apellido Paterno</th>
	<th>Apellido Materno</th>
	<th>Dni</th>
	<th>Estado</th>
	<th>Acciones</th>

	</tr>
</thead>
<tbody class="buscar">
	
	<?php $__currentLoopData = $attorney; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attorneys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
	<td><?php echo e($attorneys->id); ?></td>

	<td><?php echo e($attorneys->nombres); ?></td>
	<td><?php echo e($attorneys->apellidoPaterno); ?></td>
	<td><?php echo e($attorneys->apellidoMaterno); ?></td>
	<td><?php echo e($attorneys->dni); ?></td>
	<td><?php echo e($attorneys->estado); ?></td>




	<td>
		<a class="btn btn-info btn-xs" href="<?php echo e(route('attorneys.edit', $attorneys->id)); ?>">Editar</a>
				<form  id="deleteattorney" style="display: inline;" method="POST" action=" <?php echo e(route('attorneys.destroy', $attorneys->id)); ?>">

					<?php echo csrf_field(); ?>

					<?php echo method_field('DELETE'); ?>

					
					<button class="btn btn-danger btn-xs delete-attorney-btn" type="submit">Eliminar</button>

				</form>
	</td>

</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


	
</tbody>
</table>
<?php echo e($attorney->links('vendor.pagination.bootstrap-4')); ?>

</div>

</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>