<?php $__env->startSection('contenido'); ?>

<div class="container-fluid">


	<div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control detalle Programacion</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('programmings.create')); ?>">Agregar detalle Programacion</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
     </div>


     <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Programacion - Detalle</h5>
                                <div class="f-right">
                                	<a href="<?php echo e(route('details.create')); ?>" class="btn btn-info">Agregar detalle Programacion</a>
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>


                                </div>


                            </div>

<div class="card-block">

	<div class="container">

       	 <?php echo Form::open(['route' => 'details.index', 'method' => 'GET', 'class' => 'form-inline my-2 my-lg-0', 'role' => 'search']); ?>



       	 <?php echo Form::text('search', null , ['class' => 'form-control mr-sm-2']); ?>




      		<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
    	 <?php echo Form::close(); ?>

    </div>
	<table class="table table-hover">
	

<thead>
	<tr>
	<th>ID</th>
	<th>Programacion</th>
	<th>Docente</th>
	<th>Curso</th>
	<th>Hora Inicio</th>
	<th>Hora Fin</th>
	<th>Dia</th>
	<th>Acciones</th>
	</tr>
</thead>
<tbody>
	
	<?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($details->id); ?></td>

	<td><?php echo e($details->programming->nivel.'-'.$details->programming->grado.'-'.$details->programming->classroom->pabellon); ?></td>

	<td><?php echo e($details->teacher->nombres); ?></td>

	<td><?php echo e($details->course->name); ?></td>

	<td><?php echo e($details->hour_start); ?></td>

	<td><?php echo e($details->hour_end); ?></td>

	<td><?php echo e($details->day); ?></td>

	<td>
				<a class="btn btn-info btn-xs" href="<?php echo e(route('details.edit', $details->id)); ?>">Editar</a>


				<form  id="deleteedition" style="display: inline;" method="POST" action=" <?php echo e(route('details.destroy', $details->id)); ?>">

					<?php echo csrf_field(); ?>

					<?php echo method_field('DELETE'); ?>

					
					<button class="btn btn-danger btn-xs delete-edition-btn" type="submit">Eliminar</button>

				</form>
	</td>

</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php echo e($detail->links('vendor.pagination.bootstrap-4')); ?>


</div>

</div>
</div>
</div>




                
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>