<?php $__env->startSection('contenido'); ?>

<div class="container-fluid">

    <?php if(session()->has('info')): ?>


    <div class="alert alert-success"><?php echo e(session('info')); ?></div>

    <?php else: ?>
            <!-- Main content starts -->
            <div>
                <!-- Row Starts -->
                <div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Aulas</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('classrooms.create')); ?>">Agregar Aula</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
                </div>
                    <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Registro de Aula</h5>
                                <div class="f-right">
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>
                                </div>
                            </div>

<div class="card-block">
<form method="POST" action=" <?php echo e(route('classrooms.store')); ?> ">

    <?php echo csrf_field(); ?>


<div class="form-group">
    <label for="nombre" class="form-control-label">Nombre</label>
    <input type="text" class="form-control" id="nombre" aria-describedby="emailHelp" placeholder="Enter nombre" name="nombre" value="<?php echo e(old('nombre')); ?>">

    <?php echo $errors->first('nombre','<span class=error>:message</span>'); ?>

</div>

<div class="form-group">
    <label for="capacidad" class="form-control-label">Capacidad</label>
    <input type="text" class="form-control" id="capacidad" aria-describedby="emailHelp" placeholder="capacidad" name="capacidad" value="<?php echo e(old('capacidad')); ?>" onkeyup="copiar()">

    <?php echo $errors->first('capacidad','<span class=error>:message</span>'); ?>

</div>
 
 
<div class="form-group">
    <label for="vacante" class="form-control-label">Vacante</label>
        <input type="text" class="form-control"  id="vacante" placeholder="vacante"  name="vacante" value="<?php echo e(old('vacante')); ?>" >

        <?php echo $errors->first('vacante','<span class=error>:message</span>'); ?>

</div>

<div class="form-group">
    <label for="pabellon" class="form-control-label">pabellon</label>
        <input type="text" class="form-control" id="pabellon" placeholder="Description"  name="pabellon" value="<?php echo e(old('pabellon')); ?>">

        <?php echo $errors->first('pabellon','<span class=error>:message</span>'); ?>

</div>

 
<input class="btn btn-success waves-effect waves-light m-r-30" type="submit" name="Enviar">

</form>
</div>
</div>
</div>
    </div>
    </div>
    </div>



<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>