<?php $__env->startSection('contenido'); ?>

<?php if( session()->has('info')): ?>
<div class="alert alert-success"><?php echo e(session('info')); ?></div>

<?php endif; ?>

<div class="container-fluid">


	<div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Matricula</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="">Editar Matricula</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
     </div>


     				<div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Edicion de Matricula</h5>
                                <div class="f-right">
                                
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>


                                </div>


                            </div>

<div class="card-block">

<form method="POST" action=" <?php echo e(route('enrollments.update', $enrollment->id)); ?> ">
	<?php echo method_field('PUT'); ?>


	<?php echo csrf_field(); ?>


<div class="form-group col-md-4">

    <label for="user_id" class="form-control-label">CODIGO ALUMNO</label>
        <select class="form-control" id="edit-asig" name="user_id">
           
            <option value="">Seleccione Alumno</option>
                     <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $username): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($id); ?>"

                    <?php echo e($enrollment->user_id == $id ? 'selected="selected"' : ''); ?>>

                    <?php echo e($username); ?>

                    </option>
         
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <?php echo $errors->first('user_id','<span class=error>:message</span>'); ?>

    

</div>
<div class="form-group col-md-4">

    <label for="student_id" class="form-control-label">ESTUDIANTE</label>
        <select class="form-control" id="edit-asig" name="student_id">
           
            <option value="">Seleccione Estudiante</option>
                     <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $nombres): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($id); ?>"

                    <?php echo e($enrollment->student_id == $id ? 'selected="selected"' : ''); ?>>

                    <?php echo e($nombres); ?>

                    </option>
         
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <?php echo $errors->first('student_id','<span class=error>:message</span>'); ?>

    

</div>


<div class="form-group col-md-4">

    <label for="programming_id" class="form-control-label">PROGRAMACION</label>
        <select class="form-control" id="edit-asig" name="programming_id">
           
            <option value="">Seleccione Programacion</option>
                     <?php $__currentLoopData = $programming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($getid->id); ?>"

                    <?php echo e($enrollment->programming_id == $getid->id ? 'selected="selected"' : ''); ?>>

                    <?php echo e($getid->nivel .'-'. $getid->grado .'-'. $getid->classroom->pabellon); ?>

                    </option>
         
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <?php echo $errors->first('programming_id','<span class=error>:message</span>'); ?>

</div>

<div class="form-group col-md-4">
<label for="monto" class="form-control-label">Monto</label>

    <input class="form-control" type="text" name="monto" value="<?php echo e($enrollment->monto); ?>">

    <?php echo $errors->first('monto','<span class=error>:message</span>'); ?>

</label>

</div>


<div class="form-group col-md-12">
	
	<input class="btn btn-primary" type="submit" name="Enviar">

</div>

</form>



</div>
</div>
</div>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>