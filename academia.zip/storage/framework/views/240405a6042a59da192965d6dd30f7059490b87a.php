<?php $__env->startSection('contenido'); ?>

<div class="container-fluid">

    <?php if(session()->has('info')): ?>


    <div class="alert alert-success"><?php echo e(session('info')); ?></div>

    <?php else: ?>
            <!-- Main content starts -->
            <div>
                <!-- Row Starts -->
                <div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Notas</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('qualifications.create')); ?>">Agregar Nota</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
                </div>
                    <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Registro de Notas</h5>
                                <div class="f-right">
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>
                                </div>
                            </div>

<div class="card-block">
<form method="POST" action=" <?php echo e(route('qualifications.store')); ?> ">

    <?php echo csrf_field(); ?>



        <select name="trimester_id">

        <?php $__currentLoopData = $trimester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $see): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <option value="<?php echo e($see->id); ?>" id="trimester_id"> <?php echo e($see->name); ?></option>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>
      <select name="course_id">

        <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <option value="<?php echo e($courses->id); ?>" id="course_id"> <?php echo e($courses->name); ?></option>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>


      <select name="programacion" id="programacion">

        <?php $__currentLoopData = $selector; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selectors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <option value="<?php echo e($selectors->id); ?>" > <?php echo e($selectors->nivel.''.$selectors->grado.''.$selectors->classroom->pabellon); ?></option>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>





<table class="table-responsive">
    
    <thead class="">
        <tr>
            <td class="">Alumnos</td>
            <td class="">Notas 1</td>
            <td class="">Notas 2</td>
            <td class="">Notas 3</td>
            <td class="">Notas 4</td>
            <td class="">promedio</td> 
                 

        </tr>
    </thead>
    <tbody class="">

        <?php $__currentLoopData = $enrollment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            
            <td class=""> 

             <input type="checkbox" name="enrollment_id[]" value="<?php echo e($enrollments->id); ?>"><?php echo e($enrollments->user->username); ?>   
               <!-- <input type="text" name="enrollment_id" >-->

            </td>
            <td class=""> <input type="text" name="nota1" value="0"></td>
             <td class=""> <input type="text" name="nota2" value="0"></td>
             <td class=""> <input type="text" name="nota3" value="0"></td>
                <td class=""> <input type="text" name="nota4" value="0"></td>
             <td class=""> <input type="text" name="promedio" value="0"></td>
           

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>

 
<input class="btn btn-success waves-effect waves-light m-r-30" type="submit" name="Enviar">

</form>
</div>
</div>
</div>
    </div>
    </div>
    </div>



<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>