<?php $__env->startSection('contenido'); ?>

<div class="container-fluid">

    <?php if(session()->has('info')): ?>


    <div class="alert alert-success"><?php echo e(session('info')); ?></div>

    <?php else: ?>
            <!-- Main content starts -->
            <div>
                <!-- Row Starts -->
                <div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control detalle Programacion</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('details.create')); ?>">Agregar detalle Programacion</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
                </div>
                    <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Registro detalle Programacion</h5>
                                <div class="f-right">
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>
                                </div>
                            </div>

<div class="card-block">
<form method="POST" action=" <?php echo e(route('details.store')); ?> ">

    <?php echo csrf_field(); ?>


<div class="form-group col-md-4">
    <label for="programming_id" class="form-control-label">Programacion</label>
        
        <select name="programming_id" id="schearProgramming" style="width: 150px;">

            <?php $__currentLoopData = $programming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programmings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <option value="<?php echo e($programmings->id); ?>"> <?php echo e($programmings->nivel .'  '.$programmings->grado .'-'. $programmings->classroom->pabellon); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <?php echo $errors->first('programming_id','<span class=error>:message</span>'); ?>

</div>

<div class="form-group col-md-4">
    <label for="teacher_id" class="form-control-label">Docente</label>
        
        <select name="teacher_id" id="schearDetail" style="width: 250px;">

            <?php $__currentLoopData = $teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teachers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <option value="<?php echo e($teachers->id); ?>"> <?php echo e($teachers->nombres .' '.$teachers->apellidoPaterno); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <?php echo $errors->first('teacher_id','<span class=error>:message</span>'); ?>

</div>

<div class="form-group col-md-4">
    <label for="course_id" class="form-control-label">Curso</label>
        
        <select name="course_id" id="schearCourse">

            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <option value="<?php echo e($courses->id); ?>"> <?php echo e($courses->name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <?php echo $errors->first('course_id','<span class=error>:message</span>'); ?>

</div>



<div class="form-group col-md-4">

   <label for="hour_start" class="form-control-label">Hora de Inicio</label> 
    <input type="text" id="timepicker" name="hour_start" class="form-control">
</div>

<div class="form-group col-md-4">

   <label for="hour_end" class="form-control-label">Hora de Fin</label> 
    <input type="text" id="timepicker1" name="hour_end" class="form-control">
</div>

<div class="form-group col-md-4">
    <label for="day" class="form-control-label">Dia</label>
    <select name="day" class="form-control">
        <option value="lunes">Lunes</option>
        <option value="martes">Martes</option>
        <option value="miercoles">Miercoles</option>
        <option value="jueves">Jueves</option>
        <option value="viernes">Viernes</option>

    </select>

    <?php echo $errors->first('day','<span class=error>:message</span>'); ?>

</div>




<input class="btn btn-success waves-effect waves-light m-r-30" type="submit" name="Enviar">

</form>
</div>
</div>
</div>
    </div>
    </div>
    </div>



<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>