    

    <?php $__env->startSection('contenido'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="main-header">
                <h4>Perfil</h4>
                <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('users.show',$users->id)); ?>">Perfil</a>
                    </li>
                </ol>
            </div>
        </div>
        <!-- Header end -->
        <div class="row">
            <div class="col-xl-3 col-lg-4">
                <div class="card faq-left">
                    <div class="social-profile">
                        <img class="img-fluid" src="<?php echo e(Storage::url($users->avatar)); ?>" alt="">
                        
                    </div>
                    <div class="card-block">
                        <h4 class="f-18 f-normal m-b-10 txt-primary"><?php echo e($users->name); ?></h4>
                        
                        
                        <ul>
                            <li class="faq-contact-card">
                                <i class="icofont icofont-world"></i>
                                <a href="http://phoenixcoded.com">www.phoenixcoded.com</a>
                            </li>
                        </ul>


                    </div>
                </div>
                <!-- end of card-block -->
                
                <!-- end of card -->
            </div>
            <!-- end of col-lg-3 -->

            <!-- start col-lg-9 -->
            <div class="col-xl-9 col-lg-8">
                <!-- Nav tabs -->
                <div class="tab-header ">
                    <ul class="nav nav-tabs md-tabs tab-timeline" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#personal" role="tab">Accesos</a>
                            <div class="slide"></div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#project" role="tab">Datos personales</a>
                            <div class="slide"></div>
                        </li>
                      
                    </ul>
                </div>
                <!-- end of tab-header -->

                <div class="tab-content">
                    <div class="tab-pane active" id="personal" role="tabpanel">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text"></h5>


                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $users)): ?>

                                <a class="btn btn-primary waves-effect waves-light f-left" href="<?php echo e(route('users.edit', $users->id)); ?>"><i  class="icofont icofont-edit"></i>Cambiar Contraseña</a>

                                <?php endif; ?>

                            </div>
                            <div class="card-block">
                                <div class="view-info">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="general-info">
                                                <div class="row">
                                                    <div class="col-lg-12 col-xl-6">
                                                        <table class="table m-0">
                                                            <tbody>
                                                                <tr>
                                                                    <th scope="row">Nombre</th>
                                                                    <td><?php echo e($users->name); ?></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <!-- end of table col-lg-6 -->

                                                    <div class="col-lg-12 col-xl-6">
                                                        <table class="table">
                                                            <tbody>
                                                                <tr>
                                                                    <th scope="row">Codigo</th>
                                                                    <td><a href="#!"> <?php echo e($users->username); ?></a></td>
                                                                </tr>
                                                                

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <!-- end of table col-lg-6 -->
                                                </div>
                                                <!-- end of row -->
                                            </div>
                                            <!-- end of general info -->
                                        </div>
                                        <!-- end of col-lg-12 -->
                                    </div>
                                    <!-- end of row -->
                                </div>
                                <!-- end of view-info -->


                                <!-- end of view-info -->
                            </div>
                            <!-- end of card-block -->
                        </div>
                        <!-- end of card-->

                    </div>
                    <!-- end of tab-pane -->
                    <!-- end of about us tab-pane -->

                    <!-- start tab-pane of project tab -->
                    <div class="tab-pane" id="project" role="tabpanel">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-header-text">Datos personales</h5>

                            </div>
                            <!-- end of card-header  -->
                            <div class="row">
                                <div class="col-lg-12 col-xl-6">
                                    <table class="table m-0">
                                        <tbody>
                                            <tr>
                                            <?php $__currentLoopData = $users->student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                 
                                            <th scope="row">Full Name</th>
                                            <td>
                                                    <?php echo e($students->nombres); ?>

                                            </td>
                                            </tr>

                                            <tr>
                                                <th scope="row">Apellido Paterno</th>

                                                <td><?php echo e($students->apellidoPaterno); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Apellido Materno</th>
                                                <td><?php echo e($students->apellidoMaterno); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Email</th>
                                                <td><?php echo e($students->email); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Dni</th>
                                                <td><?php echo e($students->dni); ?></td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-lg-12 col-xl-6">
                                    <table class="table">
                                        <tbody>

                                            <tr>
                                                <th scope="row">Sexo</th>
                                                <td><?php echo e($students->sexo); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Fecha nacimiento</th>
                                                <td><?php echo e($students->fecha_nacimiento); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Distrito</th>
                                                <td><?php echo e($students->distrito); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Departamento</th>
                                                <td><?php echo e($students->departamento); ?></td>
                                            </tr>
                                        </tbody>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                           

                           <div class="row">
                               
                                    <div class="col-lg-12 col-xl-6">
                                    <table class="table m-0">
                                        <tbody>
                                            <tr>
                                            <?php $__currentLoopData = $users->attorney; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attorneys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                 
                                            <th scope="row">Full Name</th>
                                            <td>
                                                    <?php echo e($attorneys->nombres); ?>

                                            </td>
                                            </tr>

                                            <tr>
                                                <th scope="row">Apellido Paterno</th>

                                                <td><?php echo e($attorneys->apellidoPaterno); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Apellido Materno</th>
                                                <td><?php echo e($attorneys->apellidoMaterno); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Dni</th>
                                                <td><?php echo e($attorneys->dni); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Sexo</th>
                                                <td><?php echo e($attorneys->sexo); ?></td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-lg-12 col-xl-6">
                                    <table class="table">
                                        <tbody>

                                            <tr>
                                                <th scope="row">Estado Civil</th>
                                                <td><?php echo e($attorneys->est_civil); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Direccion</th>
                                                <td><?php echo e($attorneys->direccion); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Celular</th>
                                                <td><?php echo e($attorneys->celular); ?></td>
                                            </tr>
                                        </tbody>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>


                           </div>
                        </div>
                    </div>
                    <!-- end of main tab content -->
                </div>
            </div>

        </div>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>