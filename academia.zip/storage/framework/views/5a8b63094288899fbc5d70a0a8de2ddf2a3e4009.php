<?php $__env->startSection('contenido'); ?>

 <div>
                <!-- Row Starts -->
                <div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Seccion Notas</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
                    <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                          

<div class="card-block">
<table class="table table-hover">
	

<thead>

	<tr>
	<th>Curso</th>
	<th>nota1</th>
	<th>nota2</th>
	<th>nota3</th>
	<th>nota4</th>
	<th>promedio</th>
	<th>Trimestre</th>
	</tr>
</thead>
<tbody>
	


	<?php $__currentLoopData = $qualification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	

	<tr>

	<td><?php echo e($notes->course->name); ?></td>

	<td>

		<?php if(  $notes->nota1  >= 13): ?>

			<span style="color: blue"> <?php echo e($notes->nota1); ?> </span>

		<?php else: ?>	

			<span style="color: red"> <?php echo e($notes->nota1); ?> </span>
		
		<?php endif; ?>


	</td>

	<td>

		<?php if(  $notes->nota2  >= 13): ?>

			<span style="color: blue"> <?php echo e($notes->nota2); ?> </span>

		<?php else: ?>	

			<span style="color: red"> <?php echo e($notes->nota2); ?> </span>
		
		<?php endif; ?>


	</td>

	<td>

		<?php if(  $notes->nota3  >= 13): ?>

			<span style="color: blue"> <?php echo e($notes->nota3); ?> </span>

		<?php else: ?>	

			<span style="color: red"> <?php echo e($notes->nota3); ?> </span>
		
		<?php endif; ?>


	</td>

	<td>

			<?php if(  $notes->nota4  >= 13): ?>

			<span style="color: blue"> <?php echo e($notes->nota4); ?> </span>

		<?php else: ?>	

			<span style="color: red"> <?php echo e($notes->nota4); ?> </span>
		
		<?php endif; ?>



	</td>

	<td>

		<?php if(  $notes->promedio  >= 13): ?>

			<span style="color: blue"> <?php echo e($notes->promedio); ?> </span>

		<?php else: ?>	

			<span style="color: red"> <?php echo e($notes->promedio); ?> </span>
		
		<?php endif; ?>

	</td>

	<td><?php echo e($notes->trimester->name); ?></td>

</tr>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>


</table>
</div>
</div>
</div>
</div></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>