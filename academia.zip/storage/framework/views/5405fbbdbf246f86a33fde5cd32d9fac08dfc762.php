<?php $__env->startSection('contenido'); ?>

<?php if( session()->has('info')): ?>
<div class="alert alert-success"><?php echo e(session('info')); ?></div>

<?php endif; ?>

<div class="container-fluid">


	<div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Roles</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="">Editar Rol</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
     </div>


     				<div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Edicion de Roles</h5>
                                <div class="f-right">
                                
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>


                                </div>


                            </div>

<div class="card-block">



<form method="POST" action=" <?php echo e(route('trimesters.update', $trimester->id)); ?> ">
	<?php echo method_field('PUT'); ?>


	<?php echo csrf_field(); ?>


<div class="form-group col-md-4">
<label for="name" class="form-control-label">Trimestre</label>


	<input class="form-control" type="text" name="name" value="<?php echo e($trimester->name); ?>">

	<?php echo $errors->first('name','<span class=error>:message</span>'); ?>



</div>




<div class="form-group col-md-12">
	
	<input class="btn btn-primary" type="submit" name="Enviar">

</div>

</form>



</div>

</div>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>