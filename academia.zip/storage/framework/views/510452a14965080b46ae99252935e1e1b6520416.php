<?php $__env->startSection('contenido'); ?>


<h1>MOSTRAR URLS AMIGABLES</h1>



<a href="/mostrarapoderados">MIS HIJOS</a>
<br>
<br>
<a href="">RELACION HASMANY</a>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>