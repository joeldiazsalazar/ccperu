<?php $__env->startSection('contenido'); ?>

<div class="container-fluid">


	<div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Trimestre</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('trimesters.create')); ?>">Agregar Trimestre</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
     </div>


     <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Registro de Trimestre</h5>
                                <div class="f-right">
                                	<a href="<?php echo e(route('trimesters.create')); ?>" class="btn btn-info">Agregar Nuevo Trimestre</a>
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>


                                </div>


                            </div>

<div class="card-block">


	<table class="table table-hover">
	
<thead>
	<tr>
	<th>ID</th>
	<th>Nombre</th>

	<th>Acciones</th>
	</tr>
</thead>
<tbody>
	
	<?php $__currentLoopData = $trimester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trimesters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($trimesters->id); ?></td>

	<td><?php echo e($trimesters->name); ?></td>


	<td>
				<a class="btn btn-info btn-xs" href="<?php echo e(route('trimesters.edit', $trimesters->id)); ?>">Editar</a>


		
	</td>

</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>


</div>

</div>
</div>
</div>




                
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>