<?php $__env->startSection('contenido'); ?>

<div class="container-fluid">

    <?php if(session()->has('info')): ?>


    <div class="alert alert-success"><?php echo e(session('info')); ?></div>

    <?php else: ?>
            <!-- Main content starts -->
            <div>
                <!-- Row Starts -->
                <div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Notas</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('qualifications.create')); ?>">Agregar Nota</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
                </div>
                    <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Registro de Notas</h5>
                                <div class="f-right">
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>
                                </div>
                            </div>

<div class="card-block">
<form method="POST" action=" <?php echo e(route('qualifications.update', $qualification->id)); ?> " id="update">

    <?php echo method_field('PUT'); ?>

    
    <?php echo csrf_field(); ?>



      





<table class="table-responsive">
    
    <thead class="">
        <tr>
            <td class="">Alumnos</td>
            <td class="">Notas 1</td>
            <td class="">Notas 2</td>
            <td class="">Notas 3</td>
            <td class="">Notas 4</td>
            <td class="">promedio</td> 
                 

        </tr>
    </thead>
    <tbody class="">

       
        <tr>
            
            <td class=""> 

             <input type="checkbox" name="user_id" checked="" value="<?php echo e($qualification->user_id); ?>"><?php echo e($qualification->user->name); ?>   
               <!-- <input type="text" name="enrollment_id" >-->

            </td>
         
            <td><input type="text" name="nota1"  id="n1" value="<?php echo e($qualification->nota1); ?>" onkeyup="calcularUpdate();" 
            style="width: 40px; text-align: center;" /></td>
            <td><input type="text" name="nota2"  id="n2" value="<?php echo e($qualification->nota2); ?>" onkeyup="calcularUpdate();" style="width: 40px; text-align: center;" /></td>
            <td><input type="text" name="nota3"  id="n3" value="<?php echo e($qualification->nota3); ?>" onkeyup="calcularUpdate();" style="width: 40px; text-align: center;" /></td>
            <td><input type="text" name="nota4"  id="n4" value="<?php echo e($qualification->nota4); ?>" onkeyup="calcularUpdate();" style="width: 40px; text-align: center;" /></td>
            <td > <input type="text" name="promedio" id="total"  value="<?php echo e($qualification->promedio); ?>" style="width: 40px; text-align: center;" /></td>
         

        </tr>
        
 
    </tbody>

</table>


 
<input class="btn btn-success waves-effect waves-light m-r-30" type="submit" name="Enviar">

</form>
</div>
</div>
</div>
    </div>
    </div>
    </div>



<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>