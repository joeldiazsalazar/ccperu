<?php $__env->startSection('contenido'); ?>

<div class="container-fluid">

    <?php if(session()->has('info')): ?>


    <div class="alert alert-success"><?php echo e(session('info')); ?></div>

    <?php else: ?>
            <!-- Main content starts -->
            <div>
                <!-- Row Starts -->
                <div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Roles</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('roles.create')); ?>">Agregar Rol</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
                </div>
                    <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Registro de Roles</h5>
                                <div class="f-right">
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>
                                </div>
                            </div>

<div class="card-block">
<form method="POST" action=" <?php echo e(route('roles.store')); ?> ">

    <?php echo csrf_field(); ?>


<div class="form-group">
    <label for="name" class="form-control-label">Nombre</label>
    <input type="text" class="form-control" id="name" aria-describedby="emailHelp" placeholder="Enter Rol" name="name" value="<?php echo e(old('name')); ?>">

    <?php echo $errors->first('name','<span class=error>:message</span>'); ?>

</div>

<div class="form-group">
    <label for="display_name" class="form-control-label">Nombre a mostrar</label>
    <input type="text" class="form-control" id="display_name" aria-describedby="emailHelp" placeholder="Nombre a mostrar" name="display_name" value="<?php echo e(old('display_name')); ?>">

    <?php echo $errors->first('display_name','<span class=error>:message</span>'); ?>

</div>
 
 
<div class="form-group">
    <label for="description" class="form-control-label">Description</label>
        <input type="text" class="form-control" id="description" placeholder="Description"  name="description" value="<?php echo e(old('description')); ?>">

        <?php echo $errors->first('description','<span class=error>:message</span>'); ?>

</div>
 
<input class="btn btn-success waves-effect waves-light m-r-30" type="submit" name="Enviar">

</form>
</div>
</div>
</div>
    </div>
    </div>
    </div>



<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>