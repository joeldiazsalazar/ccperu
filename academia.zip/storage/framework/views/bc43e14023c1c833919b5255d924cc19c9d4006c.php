<?php $__env->startSection('contenido'); ?>

<div class="container-fluid">


	<div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Usuarios</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('users.create')); ?>">Agregar Usuario</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
     </div>


     <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Registro de Usuarios</h5>
                                <div class="f-right">
                                	<a href="<?php echo e(route('users.create')); ?>" class="btn btn-info">Agregar Usuario</a>
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>

                                </div>
                                <div class="modal fade modal-flex" id="input-type-Modal" tabindex="-1" role="dialog">
										<div class="modal-dialog modal-lg" role="document">
											<div class="modal-content">
												<div class="modal-header">
													<button type="button" class="close" data-dismiss="modal" aria-label="Close">
														<span aria-hidden="true">&times;</span>
													</button>
													<h5 class="modal-title">Code Explanation for Border Checkbox</h5>
												</div>
												<!-- end of modal-header -->
												<div class="modal-body">
									                      


												</div>
												<!-- end of modal-body -->
											</div>
											<!-- end of modal-content -->
										</div>
										<!-- end of modal-dialog -->
									</div>

                            </div>

<div class="card-block">

	<div class="container">

       	 <?php echo Form::open(['route' => 'users.index', 'method' => 'GET', 'class' => 'form-inline my-2 my-lg-0', 'role' => 'search']); ?>



       	 <?php echo Form::text('search', null , ['class' => 'form-control mr-sm-2']); ?>




      		<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
    	 <?php echo Form::close(); ?>

    </div>
<div class="container">

	
<div id="no-more-tables">
	<table class="col-sm-12 table-bordered table-striped table-condensed cf">
	

<thead>
	<tr>
	<th>ID</th>
	<th>Nombre</th>
	<th>Rol</th>
	<th>Asignacion</th>
	<th>Acciones</th>
	</tr>
</thead>
<tbody>
	
	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
	<td data-title="ID"><?php echo e($user->id); ?></td>

	<td data-title="Nombre"><?php echo e($user->name); ?></td>



	<td data-title="Rol"><?php echo e($user->role->display_name); ?></td>
	
	<td data-title="Asignacion">

		<?php $__currentLoopData = $user->student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		

			<?php echo e($students->email); ?>


		
		
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<?php $__currentLoopData = $user->attorney; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attorneys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		

			<?php echo e($attorneys->nombres); ?>


		
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
		<?php $__currentLoopData = $user->teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teachers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		

			<?php echo e($teachers->correo); ?>


		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		
	
	</td>

	<td>
		<a class="btn btn-info btn-xs" href="<?php echo e(route('users.edit', $user->id)); ?>">Editar</a>
				<form style="display: inline;" method="POST" action=" <?php echo e(route('users.destroy', $user->id)); ?>">

					<?php echo csrf_field(); ?>

					<?php echo method_field('DELETE'); ?>

					
					<button class="btn btn-danger btn-xs" type="submit">Eliminar</button>

				</form>
	</td>

</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	


</tbody>
</table>
</div>

<?php echo e($users->links('vendor.pagination.bootstrap-4')); ?>


</div>
</div>

</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>