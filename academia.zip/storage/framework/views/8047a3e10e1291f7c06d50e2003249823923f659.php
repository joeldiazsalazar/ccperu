<?php $__env->startSection('contenido'); ?>

<div class="container-fluid">


	<div class="row">
                    <div class="col-sm-12 p-0">
                        <div class="main-header">
                            <h4>Control de Docentes</h4>
                            <ol class="breadcrumb breadcrumb-title breadcrumb-arrow">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('cpanel')); ?>"><i class="icofont icofont-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('teachers.create')); ?>">Agregar Docente</a>
                                </li>
                                
                            </ol>
                        </div>
                    </div>
     </div>


     <div class="row">
                    <!-- Form Control starts -->
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><h5 class="card-header-text">Registro de Docentes</h5>
                                <div class="f-right">

                                	<a href="<?php echo e(route('teachers.create')); ?>" class="btn btn-info">Agregar Nuevo Docente</a>
                                	
                                    <a href="" data-toggle="modal" data-target="#input-type-Modal"><i class="icofont icofont-code-alt"></i></a>


                                </div>


                            </div>

<div class="card-block">

<div class="container">

       	 <?php echo Form::open(['route' => 'teachers.index', 'method' => 'GET', 'class' => 'form-inline my-2 my-lg-0', 'role' => 'search']); ?>



       	 <?php echo Form::text('search', null , ['class' => 'form-control mr-sm-2']); ?>




      		<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
    	 <?php echo Form::close(); ?>

    </div>

<div id="no-more-tables">
	<table class="col-sm-12 table-bordered table-striped table-condensed cf">
	

<thead>
	<tr>
	<th>ID</th>
	<th>Nombres</th>
	<th>Apellido Paterno</th>
	<th>Apellido Materno</th>
	<th>dni</th>
	<th>Estado</th>
	<th>Acciones</th>
	</tr>
</thead>
<tbody class="buscar">
	
	<?php $__currentLoopData = $teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teachers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
	<td data-title="ID"><?php echo e($teachers->id); ?></td>

	<td data-title="Nombres"><?php echo e($teachers->nombres); ?></td>
	<td data-title="ApellidoPaterno"><?php echo e($teachers->apellidoPaterno); ?></td>
	<td data-title="ApellidoMaterno"><?php echo e($teachers->apellidoMaterno); ?></td>
	<td data-title="Dni"><?php echo e($teachers->dni); ?></td>
	<td data-title="Estado"><?php echo e($teachers->estado); ?></td>



	<td>
		<a class="btn btn-info btn-xs" href="<?php echo e(route('teachers.edit', $teachers->id)); ?>">Editar</a>
		<form  style="display: inline;" method="POST" action=" <?php echo e(route('teachers.destroy', $teachers->id)); ?>">

		<?php echo csrf_field(); ?>

		<?php echo method_field('DELETE'); ?>

					
		<button class="btn btn-danger btn-xs " type="submit">Eliminar</button>

		</form>
	</td>

</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






	
</tbody>
</table>
</div>
<?php echo e($teacher->links('vendor.pagination.bootstrap-4')); ?>

</div>

</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>